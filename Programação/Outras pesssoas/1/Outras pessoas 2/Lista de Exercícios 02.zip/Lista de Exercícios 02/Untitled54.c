#include <stdio.h>
int main(){
    int esc, tot=0;
    printf("Digite um valor para saber se e primo: ");
    scanf("%d", &esc);
    if (esc > 1)
    {
        for (int i = 1; i <= esc; i++)
        {
            if ((esc % i) == 0)
                tot++;
            if (tot > 2)
            {
                printf("Nao e primo");
                return 0;
            }
        }
        printf("E primo", tot);
    }
    else
        printf("Valor invalido");
}

