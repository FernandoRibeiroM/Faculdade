#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
    srand(time(NULL));
    int random = rand() % 1000, esc;
    while (esc != random)
    {
        printf("Tente acertar o valor aleatorio: ");
        scanf("%d", &esc);
        if (esc > random)
            printf("O chute e maior que o valor gerado\n\n");
        else if (esc < random)
            printf("O chute e menor que o valor gerado\n\n");
    }
    printf("Acertou o valor!");
}
