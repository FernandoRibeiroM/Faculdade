#include <stdio.h>
int main(){
    long long total=0, tot=0, a=2, b=2000000;
    for (a; a <= b; a++)
    {
        for (long i = 1; i <= a; i++)
        {
            if ((a % i) == 0)
                tot++;
            if (tot > 2)
                break;
        }
        if (tot == 2)
        {
            total += a;
            printf("%d\n",a);
        }
        tot = 0;
    }
    printf("A soma de todos numeros primos entre 1 e 2000000 e: %ld", total);
}
