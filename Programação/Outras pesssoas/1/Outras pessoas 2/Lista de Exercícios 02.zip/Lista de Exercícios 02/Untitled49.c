#include <stdio.h>
int main(){
    float carlos = 100, joao = carlos/3;
    int mes = 0;
    while (joao <= carlos)
    {
        carlos *= 1.02;
        joao *= 1.05;
        mes++;
    }
    printf("Em %d meses o valor de joao sera igual ao valor de carlos", mes);
}
