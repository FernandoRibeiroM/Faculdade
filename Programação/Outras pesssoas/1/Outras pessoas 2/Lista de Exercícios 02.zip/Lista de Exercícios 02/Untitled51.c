#include <stdio.h>
int main(){
    float sal = 2000, ant;
    printf("Em 1995 foi contratado por R$%.2f\n", sal);
    sal *= 1.5;
    printf("Em 1996 recebeu aumento de 1.5%% e passou a receber R$%.2f\n", sal);
    for (int i = 1997; i <= 2021; i++)
    {
        ant = sal;
        sal = ant * 2;
        printf("Em %d recebia R$%.2f\n", i, sal);
    }
}

