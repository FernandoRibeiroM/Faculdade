#include <stdio.h>
#include <stdbool.h>
int main()
{
    float val;
    int esc;
    while (true){
        printf("Escolha uma opcao:\n[1] Km/h ---> m/s\n[2] m/s  ---> Km/h\n[0] Sair do progama ");
        scanf("%d", &esc);
        if (esc == 0){
            printf("Progama finalizado\n");
            return 0;
        }
        printf("Digite o valor a ser convertido: ");
        scanf("%f", &val);
        switch (esc)
        {
            case 1:
            {
                val /= 3.6;
                break;
            }
            case 2:
            {
                val *= 3.6;
                break;
            }
        }
        printf("O valor convertido e igual a: %.2f\n\n", val);
    }
}
