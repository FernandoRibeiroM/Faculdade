#include <stdio.h>
#include <stdbool.h>
int main()
{
    float val1, val2, res;
    int esc;
    while (true){
        printf("Escolha uma opcao:\n[1] Adicao\n[2] Subtracao\n[3] Multiplicacao\n[4] Divisao\n[5] Sair do progama ");
        scanf("%d", &esc);
        if (esc == 5){
            printf("Progama finalizado\n");
            return 0;
        }
        printf("Digite o valor 1: ");
        scanf("%f", &val1);
        printf("Digite o valor 2: ");
        scanf("%f", &val2);
        switch (esc)
        {
            case 1:
            {
                res = val1 + val2;
                break;
            }
            case 2:
            {
                res = val1 - val2;
                break;
            }
            case 3:
            {
                res = val1 * val2;
                break;
            }
            case 4:
            {
                res = val1 / val2;
                break;
            }
        }
        printf("Resultado igual a: %.2f\n\n", res);
    }
}
