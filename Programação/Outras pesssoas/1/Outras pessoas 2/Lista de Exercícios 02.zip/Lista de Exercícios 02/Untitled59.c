#include <stdio.h>
int main(){
    int num, i, maior, menor, N, cod;
    float soma=0, media,soma1,soma2,soma3;
    printf("Digite o numero de habitantes da cidade: ");
    scanf("%d", &N);
    for(i=1; i<=N; i++)
    {
        printf("Digite o valor do Kwh do %d habitante: ", i);
        scanf("%d", &num);
        printf("Digite o codigo do consumidor: ");
        scanf("%d", &cod);
        if (cod == 1)
            soma1 += num;
        else if (cod == 2)
            soma2 += num;
        else if (cod == 3)
            soma3 += num;
        soma += num;
    if (i == 1)

    {
        maior = menor = num;
    }
    else if(maior < num)
    {
        maior = num;
    }
    else if (menor > num)
    {
        menor = num;
    }
    }
    media =soma/ N;

    printf("Media: %.2f\n", media);
    printf("Maior: %d\n", maior);
    printf("Menor: %d\n", menor);
    printf("\n1-Residencial consumo: %.2f\n2-Comercial consumo: %.2f\n3-Industrial consumo: %.2f", soma1, soma2, soma3);
    return 0;
}


