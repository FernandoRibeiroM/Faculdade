#include <stdio.h>
int main(){
    int esc,  c=0;
    printf("Digite um valor para ver o triangulo de Floyd: ");
    scanf("%d", &esc);
    for (int i = 1; i < esc; i++)
    {
        for (int d = 0; d < i; d++)
        {
            c++;
            printf("%d ", c);
        }
    printf("\n");
    }
}

