#include <stdio.h>
int main(){
    int total=0, tot=0, a, b;
    printf("Digite o valor inicial para contar numeros primos: ");
    scanf("%d", &a);
    printf("Digite o valor final para contar numeros primos: ");
    scanf("%d", &b);
    for (a; a <= b; a++)
    {
        for (int i = 1; i <= a; i++)
        {
            if ((a % i) == 0)
                tot++;
            if (tot > 2)
                break;
        }
        if (tot == 2)
            total++;
        tot = 0;
    }
    printf("%d valores", total);
}
