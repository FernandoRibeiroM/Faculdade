#include <stdio.h>
int main()
{
    long soma = 0, previous = 0, f = 1, aux, ultimo;
    do
    {
        if(f % 2 == 0)
        {
            soma += f;
            ultimo = f;
        }
        aux = f;
        f += previous;
        previous = aux;
    } while (f <= 4000000 && soma <= 4000000);

    if(soma >= 4000000)
    {
        soma = soma - ultimo;
    }
    printf("%ld\n", soma);

    return 0;

}

