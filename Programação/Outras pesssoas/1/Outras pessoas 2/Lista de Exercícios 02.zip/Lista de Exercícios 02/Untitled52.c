#include <stdio.h>
int main(){
    int val;
    int notas100=0, notas50=0, notas20=0, notas10=0, notas5=0, notas2=0, notas1=0;
    printf("Digite o valor que deseja sacar: ");
    scanf("%d", &val);
    while (val != 0)
    {
        if ((val - 100) >= 0)
        {
            val -= 100;
            notas100++;
        }
        else if ((val - 50) >= 0)
        {
            val -= 50;
            notas50++;
        }
        else if ((val - 20) >= 0)
        {
            val -= 20;
            notas20++;
        }
        else if ((val - 10) >= 0)
        {
            val -= 10;
            notas10++;
        }
        else if ((val - 5) >= 0)
        {
            val -= 5;
            notas5++;
        }
        else if ((val - 2) >= 0)
        {
            val -= 2;
            notas2++;
        }
        else if ((val - 1) >= 0)
        {
            val -= 1;
            notas1++;
        }
    }
    printf("Serao necessarias:\n%d notas de 100\n%d notas de 50\n%d notas de 20\n%d notas de 10\n%d notas de 5\n%d notas de 2\n%d notas de 1", notas100, notas50, notas20, notas10, notas5, notas2, notas1);
}

