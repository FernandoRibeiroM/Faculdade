#include <stdio.h>

int main(){
	int n=0, i=0, soma=0;
	printf("Digite o valor de n\n");
	scanf("%d", &n);
	for(i=0;i<=n; i++){
		soma+=i;
	}
	printf("%d\n", soma);
	soma=0;
	for(i=1;i<=n; i++){
		soma+=i;
		soma-=i+1;
		i++;
	}
	printf("%d\n", soma);
	soma=0;
	for(i=1;i<=n; i++){
		soma+=i+2;
	
		i+=2;
	}
	printf("%d\n", soma);
	return 0;
}
