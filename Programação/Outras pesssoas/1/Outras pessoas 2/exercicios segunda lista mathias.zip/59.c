#include <stdio.h> 

int main()
{ 

int num, i;
int maior, menor; 
float soma=0; 
float media; 

for(i=1; i<=N; i++) { 
printf("Informe o %dº número: ", i); 
scanf("%d", &num); 
soma += num; 
 if (i == 1){
maior = menor = num; 
}
 else if(maior < num){
maior = num; 
}
 else if (menor > num){ 
menor = num; 
}
}
media =soma/ N;
 
printf("Media: %f\n", media); 
printf("Maior: %d\n", maior); 
printf("Menor: %d\n", menor); 
return 0; 
}
