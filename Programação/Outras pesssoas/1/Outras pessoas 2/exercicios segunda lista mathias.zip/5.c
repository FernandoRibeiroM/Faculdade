#include<stdio.h>

int main(){
float numero,soma;
int contador;
soma = 0;
contador = 1;

while(contador <= 10){
printf("Digite %d valor:\n",contador);
scanf("%f",numero);
soma = soma + numero;
contador++;
}
printf("A soma dos numeros e %f",soma);

return 0;
}
