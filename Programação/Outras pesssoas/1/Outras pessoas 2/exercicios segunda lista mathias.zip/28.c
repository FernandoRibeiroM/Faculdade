#include<stdio.h>


int main (){

int num,i;
float e=1.0, fat=1;

printf("Digite um numero para obter o valor de E na equacao\nE = 1 + 1/1! + 1/2! + 1/3! + .... + 1/N!:");
scanf("%d", &num);

for( i =1; i<= num ; i++)
{
fat*=i;
e = e + (1.0/ fat);
}

printf("O valor de 'E' e : %f", e);

return 0;
}
