#include<stdio.h>

int main(){
	int a,b=0;
    int c,d=0;

	printf("Digite qual a seguencia de numeros:\n");
	scanf("%d",&a);

    for(c=a;c>0;c--){
    printf("Numero: ");
    scanf("%d",&a);

    if(a == 1000){
    break;
    }
    else if(a%2==0){
    d++;
    }
    b++;
    }
    printf("Os numeros pares sao %d e os numeros lidos sao %d",d,b);
	return 0;
}
