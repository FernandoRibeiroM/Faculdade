#include <stdio.h>

int main() {

int num, i;

printf("Digite um número par: ");
scanf("%d", &num);

for (int i=1; i<=num/2; i++) {
printf ("Numero par: %d\n",i*2);

}
return 0;
}

