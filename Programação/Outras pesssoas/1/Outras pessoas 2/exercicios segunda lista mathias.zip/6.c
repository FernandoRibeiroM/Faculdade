#include<stdio.h>

int main()
{
 int i,numero;
 int soma=0;


 for(i=0;i<10;i++)
 {
    printf("Digite o valor:\n");
    scanf("%i",&numero);
    soma = soma + numero;
}
 printf("A media dos numeros e: %i",soma/10);

 return 0;
}
