#include <stdio.h>
#include <stdlib.h>

int main(){

    int min = 1; // O menor numero
    int max ;
    int i, dado1,dado2;
    int vezes;

    printf("\nQuantas vezes deseja que os dados role?");
    scanf("%d", &vezes);


for(i=1;i<=vezes; i++){

    printf("\nQuantas faces deseja que o dado possua?");
    scanf("%d", &max); // O maior numero

    dado1 = (rand () % (max-min+1) + min);
    dado2 = (rand () % (max-min+1) + min);


    printf("A face sorteada foi: %d\n", dado1); // gera numeros entre min e max
    printf("A face sorteada foi: %d\n", dado2);
if (dado1 > dado2){
    printf("Dado 1 e maior que Dado 2");
    }
else{
    printf("Dado 2 e maior que dado 1");
    }
}
return 0;
}
