#include <stdio.h>

int main() {

int n;
int aux;

printf("Informe um numero: ");
scanf("%d", &n);

if((n <= 100) || (n >= 999)) {
printf("Precisa estar entre 100 e 999");
scanf("%d", &n);
}

else if (n>100 && n<999){

aux = n;

while (aux > 0) {
printf("\t%d", aux%10);
aux /= 10;
}
printf("\n");
}
return 0;
}
