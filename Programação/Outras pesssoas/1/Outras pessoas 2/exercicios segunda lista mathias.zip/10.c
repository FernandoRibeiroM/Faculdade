#include <stdio.h>

int main() {

int i, n=2, soma=0; // numero = 2 pois sao pares

for (i=1; i<=50; i++) {
soma += n;
n += 2;
}

printf("A soma dos primeiros 50 pares e: %d\n", soma);
return 0;

}
