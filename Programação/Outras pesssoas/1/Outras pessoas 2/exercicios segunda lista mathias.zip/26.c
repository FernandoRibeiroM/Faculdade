#include<stdio.h>
#include<stdlib.h>

int main()
{
    int valor,i;
    int soma = 0;

    printf("Insira um valor para verificar os seus divisores: \n");
    scanf("%d", &valor);

    for (i = 1; i < valor+1; i++){
    if (valor%i==0){
    if(i = 11){
    printf("%d e Divisor de %d \n",i,valor);
    break;
}
    else if(i = 13){
    printf("%d e Divisor de %d \n",i,valor);
    break;
}

    else if(i = 17){
    printf("%d e Divisor de %d \n",i,valor);
    break;
}
}
}
    return 0;
}
