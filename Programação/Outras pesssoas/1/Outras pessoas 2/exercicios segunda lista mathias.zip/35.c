#include <stdio.h>

int main(){
	int n1=0,n2=0,i=0,soma=0;
	printf("Digite o primeiro valor\n");
	scanf("%d", &n1);
	printf("Digite o segundo valor\n");
	scanf("%d", &n2);
	if(n1<n2){
	
	for(i=n1;i<=n2;i++){
		if(i%2==1){
			soma+=i;
		}
	}
	printf("A soma dos impares eh: %d\n", soma);
	}else{
		printf("Intervalo de valores invalido\n");
	}
	
	return 0;
}
