#include <stdio.h>

int main(){
	int maior=0, menor=999999999, n=0;
	printf("Digite um numero\n");
	scanf("%d", &n);
	
	while(n>=0){
	if(n>maior){
		maior=n;
	}	
	if(n<menor){
		menor=n;
	}
	printf("Digite um numero\n");
	scanf("%d", &n);
	}
	
	printf("O maior numero eh: %d\nO menor numero eh: %d", maior,menor);
}
