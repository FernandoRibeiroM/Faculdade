#include <stdio.h>

main(){

    int num = 1,divi,i;

    while (num > 0){
        divi = 1;
        i = 0;
        while (divi<= 20){
            if(num % divi == 0)
                i++;
                divi++;
        }
        if (divi == 20){
            break;
        }
        num++;
    }
    printf("%d", num);
}

