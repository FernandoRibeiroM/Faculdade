#include<stdio.h>

int meses;
float salj, supera;
float rendepoupj, rendecontm, salm, supera=0;
int main ()
{


 	 printf ("Entre com o salario de João: ");
 	 scanf ("%f", &salj);

	 supera =  meses*salj;
 	 printf ("Serao necessarios %.2f meses", supera);

    salm = salj / 3;
    rendepoupj = salj;
    rendecontm = salm;

  while (rendecontm <= rendepoupj)
  {
    supera++;
    rendepoupj *= 1.02;
    rendecontm *= 1.05;
    }

	 return 0;
}
