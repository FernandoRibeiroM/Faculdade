#include <stdio.h>

int main(){
	int n=0,i=0,j=0, cont=0, total=0;
	printf("Digite o valor de n\n");
	scanf("%d", &n);
	printf("Digite o valor de i\n");
	scanf("%d", &i);
	printf("Digite o valor de j\n");
	scanf("%d", &j);
	
	while(cont!=-1){
		
		if(cont%i==0||cont%j==0){
			printf("%d, ", cont);		
		total++;
	}
	cont++;
	if(total==n){
		cont=-1;
	}
	
}
	return 0;
}
