#include <stdio.h>

main(){

    int n,i=1,maiorlido=0;
    float num,maior;

    printf("Digite a quantidade de numeros a serem lidos:  ");
    scanf("%d",&n);

    printf("Digite o numero %d: ",i);
    scanf("%f",&num);

    maior=num;

    for(i=2;i<=n;i++){

        printf("Digite o numero [%d]:  ",i);
        scanf("%f",&num);

        if(num>maior){
            maior=num;
            maiorlido++;
        }

    }
    printf("\nMaior e = %f\nQuantidade de vezes que o maior foi lido e = %d\n",maior,maiorlido);
}


