#include<stdio.h>

int main() {
int num, soma=0, qtd=0, maior, menor, qtd_pares=0, soma_pares=0, qtd_impares=0;
char outro;
do {
printf("Informe um numero: ");
scanf("%d", &num);
qtd++;
soma += num;
if (num%2 == 0) {
qtd_pares++;
soma_pares += num;
}
else {
qtd_impares++;
}
if (qtd == 1)
maior = menor = num;
else {
if (maior < num)
maior = num;
if (menor > num)
menor = num;
}
printf("Outro numero? [S/N]\n: ");
scanf("%c", &outro);
} while (outro == 's' || outro == 'S');
printf("Soma dos numeros digitados: %d\n", soma);
printf("Quantidade dos numeros digitados: %d\n", qtd);
printf("Media dos numeros digitados: %.2f\n", (float) soma / qtd);
printf("Maior numero digitado: %d\n", maior);
printf("Menor numero digitado: %d\n", menor);
printf("Media dos numeros pares: %.2f\n", (float) soma_pares / qtd_pares);
printf("Percentagem dos numeros impares em todos os numeros digitados: %.2f%\n", qtd_impares * 100.0 / qtd);
return 0;
}
