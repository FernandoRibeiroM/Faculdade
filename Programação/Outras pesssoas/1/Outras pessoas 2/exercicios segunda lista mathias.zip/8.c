#include<stdio.h>
#include<stdlib.h>

int main() {

int num;
int maior=0,menor=0,i=0;

menor = num;
maior = num;

for (i=1; i<10; i++) {
    printf("Insira o %d número: ", i);
    scanf("%d", &num);

    if(num > maior) maior = num;
    if(num < menor) menor = num;
}

    printf ("O maior numero e:%d\n",maior);
    printf ("O menor numero e:%d",menor);

return 0;
}
