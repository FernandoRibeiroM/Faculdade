#include<stdio.h>

int main(){
int numero;
numero = 10;

while(numero >=0){
    printf("\n%d",numero);
    numero--;
}
 printf("\nFIM");
return 0;
}
