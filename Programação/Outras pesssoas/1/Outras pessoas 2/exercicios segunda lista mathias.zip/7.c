#include<stdio.h>
#include<stdlib.h>

int main() {

int num, i;
float soma = 0;

for (i=1; i<=10; i++) {
    printf("Insira o %d número: ", i);
    scanf("%d", &num);
while (num <= 0) {
    printf("Numero precisa ser positivo. Insira novamente o %d numero: ", i);
    scanf("%d", &num);
}
    soma += num;
}
    printf("A media e: %.2f\n",soma / 10);

return 0;
}
