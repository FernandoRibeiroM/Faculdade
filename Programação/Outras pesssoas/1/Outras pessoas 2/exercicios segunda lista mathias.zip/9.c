#include <stdio.h>

int main() {
  int numero,i,impar;

  printf("Gerador de numeros impares\n");

  printf("\nDigite um numero: ");
  scanf("%d", &numero);
  i = 0;
  impar = 1;

  printf("Os %d primeiros impares sao:\n", numero);
  while (i < numero) {
    printf ("%d\n", impar);
    impar = impar + 2; //vai para o proximo impar
    i++;
  }

  return 0;
}
