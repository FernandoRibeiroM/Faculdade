#include<stdio.h>

int main(){
int numero;
numero = 0;

for(numero = 0;numero <= 100000; numero+=1000){
    printf("\n%d",numero);
}
return 0;
}
