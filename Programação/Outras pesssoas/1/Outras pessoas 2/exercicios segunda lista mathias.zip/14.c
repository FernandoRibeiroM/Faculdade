#include <stdio.h>

int main() {

int num;
int i=0, par=0;

par = num;

printf("Digite um número par: ");
scanf("%d", &num);

if(num%2==1){
printf("Numero Impar invalido! ");
}
else{
for (i=num; i>=0; i--){
printf ("->%d\n",par);
par = num - 2;

}

}
return 0;
}
