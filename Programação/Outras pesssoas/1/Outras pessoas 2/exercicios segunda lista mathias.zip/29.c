#include <stdio.h>


int main(){
	
	int n=0, i=0, j=0;
	float h=1, fat=1, t=0;

	
	for(t=0;t<5;t++){
	
	printf("Digite o valor de n \n");
	scanf("%d", &n);
	
	for(i=1;i<=n;i++){
		for(j=1;j<=i;j++){
			fat=fat*j;
		}
		h+=(1.0/fat);
		fat=1;
	}
	printf("O numero harmonico eh: %f\n", h);
	h=1;
}
	return 0;
}
