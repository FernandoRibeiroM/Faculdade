#include <stdio.h>

int main()
{
    int primo;
    int n1,n2;
    int cont=0;
    int i, j;
    int soma=0;
    do
    {
        printf("entre com 2 numero: ");
        scanf("%d", &n1);
        scanf("%d", &n2);
    }
    while(n1<0);
    for(i=0;i<=n1;i++)
    {
        j = primo;
        if(j==1)
        {
            printf(" %d ", i);
            soma += i;
        }
    }

        for(i=1;i<=n1;i++)
    {
        if(n1%i==0)
            cont++;
    }
    printf("\nsoma dos primeiros primos: %d\n", soma);
    return 0;
}

