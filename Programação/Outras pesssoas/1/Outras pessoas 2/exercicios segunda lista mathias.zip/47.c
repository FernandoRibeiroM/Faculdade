#include <stdio.h>

int main()
{
    float num1, num2, sum, sub, mult, div;
    int opcao;

    printf("Digite o primeiro numero: " );
    scanf("%f", &num1);

    printf("Digite o segundo numero: " );
    scanf("%f", &num2);

    printf("Digite uma Opcao\n1=Adicao\n2=Subtracao\n3=Multiplicao\n4=Divisao\n5=Saida:\n " );
    scanf("%d", &opcao);


    if (opcao == 1){
    //Soma
    sum = num1 + num2;
    printf("%.2f + %.2f = %.2f\n", num1, num2, sum);
}
    else if(opcao == 2){
    //Subtração
    sub = num1 - num2;
    printf("%.2f - %.2f = %.2f\n", num1, num2, sub);
}
    else if(opcao == 3){
    //Multiplicaçao
    mult = num1 * num2;
    printf("%.2f * %.2f = %.2f\n", num1, num2, mult);
}
    else if(opcao == 4){
    //Divisão
    div = num1/num2;
    printf("%.2f / %.2f = %.2f\n", num1, num2, div);
}
    else{
    return 0;
}
}
