#include <stdio.h>


int main(){
	
	int i=0, aux=0, aux2=0, soma=0,mult=0;
	
	for(i=1000;i<=9999;i++){
		aux=i/100;
		aux2=i%100;
		soma=aux+aux2;
		if(soma*soma==i){
			mult=soma*soma;
			printf("%d+%d == %dx%d = %d \n", aux,aux2,soma,soma,mult);
		}
	}
	return 0;
}
