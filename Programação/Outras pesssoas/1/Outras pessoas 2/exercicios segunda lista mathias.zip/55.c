#include <stdio.h>

int main()
{
    int primo;
    int n;
    int cont=0;
    int i, j;
    int soma=0;
    do
    {
        printf("entre com numero: ");
        scanf("%d", &n);
    }
    while(n<0);
    for(i=0;i<=n;i++)
    {
        j = primo;
        if(j==1)
        {
            printf(" %d ", i);
            soma += i;
        }
    }

        for(i=1;i<=n;i++)
    {
        if(n%i==0)
            cont++;
    }
    if(cont==2)
        return 1;
    else

    printf("\nsoma dos primeiros primos: %d\n", soma+soma);
}

