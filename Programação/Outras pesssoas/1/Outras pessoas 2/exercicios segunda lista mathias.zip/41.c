#include <stdio.h>
#include <stdlib.h>

int main() {
  int cont, i;
  float r1, r2 ,rt;

  printf("Quantidade de resistores: ");
  scanf("%d", &cont);

  printf("Valor do resistor 1: ");
  scanf("%f", &r1);
  for(i = 1; i < cont; i++) {
    printf("Valor do resistor %d: ", i + 1);
    scanf("%f", &r2);
    rt = (r1 * r2) / (r1 + r2);
  }
  printf("Resistencia = %f\n", rt);
  return 0;
}
