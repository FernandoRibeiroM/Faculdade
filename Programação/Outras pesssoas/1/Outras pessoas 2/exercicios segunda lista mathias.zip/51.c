#include<stdio.h>
#include<stdlib.h>

int main(){
float perc = 1.5;
float salario;
int anoini, i, at;

printf("Digite salario inicial=2000 ");
scanf("%f", &salario);

printf("Digite ele foi contratado=1995 ");
scanf("%d", &anoini);

printf("Digite o ano atual=2019 ");
scanf("%d", &at);

for(i=anoini; i<=at; i++){
if(i!=anoini){
salario=salario+salario*perc/100;
perc=perc*2;
}
printf("%d - %.2f - %.2f\n", i, perc, salario );
}

printf("O salario dele e %.2f", salario);
return 0;
}

