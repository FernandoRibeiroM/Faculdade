#include<stdio.h>

int main(){

float s = 0, j = 1;
int i;

for(i=1; i<100; i++){
    if (i % 2 !=0){
    s+= i/j;
    j++;
    }
}
printf("A Valor de S= %f",s);
return 0;
}
