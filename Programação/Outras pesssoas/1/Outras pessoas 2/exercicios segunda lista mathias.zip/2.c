#include<stdio.h>

int main(){
int numero;
numero = 1;

for(numero=1;numero <=100;numero++){
    printf("\n\n%d",numero);
}

numero = 1;
while (numero <= 100){
    printf("\n\n%d",numero);
    numero++;
}

numero = 1;
do{
    printf("\n\n%d",numero);
    numero++;
}while(numero <= 100);



return 0;
}
