#include <stdio.h>

int main() {

    int X = 0, Y = 0, par = 0, impar = 1;//x primeiro, y segundo

    printf("Insira o primeiro valor: ");
    scanf("%d", &X);
    printf("Insira o segundo valor: ");
    scanf("%d", &Y);

    if (Y <= X) {
        printf("Primeiro valor nao pode ser maior que o segundo\n");
        return 0;
    }
    for (int cont = X; cont <= Y; cont++) {
        if (cont % 2 == 0) {
            par += cont;
        } else {
            impar *= cont;
        }
    }
    printf("A soma dos numeros pares nesse intervalo e %d\n", par);
    printf("A multiplicação dos numeros impares nesse intervalo e %d\n", impar);

    return 0;
}

