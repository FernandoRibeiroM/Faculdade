#include <stdio.h>

int main() {

int num, i;

printf("Digite um número impar: ");
scanf("%d", &num);

for (int i=0; i<=num/2; i++) {
printf ("Numero par: %d\n",i*3);

}
return 0;
}
