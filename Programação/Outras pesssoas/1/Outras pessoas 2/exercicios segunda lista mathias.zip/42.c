#include <stdio.h>
#include <math.h>

int main(){

	int nInput;
	float nQuadrado, nCubo, nRaiz;

	printf("\n Exercicio de Calculo - Informe zero ou negativo para sair ");
    printf("\n------------------------------------------------------------");
    nInput = 1;

    while (nInput > 0){
    printf("\n Digite um numero: ");
    scanf("%i", &nInput);
    if (nInput > 0) {
    nQuadrado = pow(nInput,2);
    nCubo = pow(nInput,3);
    nRaiz = sqrt(nInput);
    printf("\n QUADRADO: %f ", nQuadrado);
    printf("\n CUBO: %f ", nCubo);
    printf("\n RAIZ: %f ", nRaiz);
    }

    printf("\n\n Exercicio de Calculo - Informe zero ou negativo para sair ");
    printf("\n------------------------------------------------------------");
}
return 0;
}

