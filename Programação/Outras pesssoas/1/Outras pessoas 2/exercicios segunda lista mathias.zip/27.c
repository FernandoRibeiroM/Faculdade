#include<stdio.h>

int main(){

int x;
float b,i;
b=0;

    printf("Digite um numero: ");
    scanf("%d",&x);

for(i=1;i<=x;i++){
    b=b+1.0/i;
}
    printf("O numero harmonico de %d e %f \n", x,b);

return 0;
}
