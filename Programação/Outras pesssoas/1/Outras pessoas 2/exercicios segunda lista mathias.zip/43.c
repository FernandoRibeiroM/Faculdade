#include<stdio.h>

int main()
{
      int idade, media=0, num, cont=0;

      printf("Digite quantas idades deseja calcular: ");
      scanf("%d",&num);

      while(cont<num)
      {
           printf("Digite uma idade: ");
           scanf("%d",&idade);

           media=media+idade;
           cont++;
      }

      printf("A media de idade e: %d",media/num);
      return 0;
}
