#include <stdio.h>

int main(){
	
	int i=0, soma=0, soma2=0, res=0;
	for(i=0;i<=100;i++){
		soma+=(i*i);
		soma2+=i;
	}
	soma2=soma2*soma2;
	res=soma2-soma;
	printf("%d\n", res);
	
	
	
	return 0;	
}
