#include <stdio.h>

main(){

    float salarioA,tempo,salario;

    printf("Digite o seu sálario atual:  ");
    scanf("%f",&salarioA);

    printf("Digite o tempo de serviço (anos):  ");
    scanf("%f",&tempo);

    if (salarioA <= 500){
        salario = salarioA*1.25;
        printf("\nO salário foi reajustado para %f\n",salario);
    }

    else if (salarioA <= 1000){
        salario = salarioA*1.20;
        printf("\nO salário foi reajustado para %f\n",salario);
    }

    else if (salarioA <= 1500){
        salario = salarioA*1.15;
        printf("\nO salário foi reajustado para %f\n",salario);
    }

    else if (salarioA <= 2000){
        salario = salarioA*1.10;
        printf("\nO salário foi reajustado para %f\n",salario);
    }

    else if (salarioA > 2000){
        salario = salarioA*1.10;
        printf("\nO salário não teve reajuste e foi para %f\n",salario);
   }

    if(tempo<1)
        printf("\nCom bonus = %f\n",salario);
    if(tempo>=1 && tempo<=3)
        printf("\nCom bonus = %f\n",salario+100);
    if(tempo>=4 && tempo<=6)
        printf("\nCom bonus = %f\n",salario+200);
    if(tempo>=7 && tempo<=10)
        printf("\nCom bonus = %f\n",salario+300);
    if(tempo>10)
        printf("\nCom bonus = %f\n",salario+500);


}

