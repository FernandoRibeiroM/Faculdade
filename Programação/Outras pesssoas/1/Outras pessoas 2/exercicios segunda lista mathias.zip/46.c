#include<stdio.h>
#include<stdlib.h>

int main(){

int escolha= 0;
int a;
int b = 1;
int num_tenta= 0;
int retorno=0, teste= 0, contador=2, numero=0;

printf("====== TENTE ACERTAR UM NUMERO DE 1 A 1000 ====== \n\n");
printf(" ===== FUNCIONA ASSIM: ===== \n A CADA TENTATIVA VAMOS TE DAR UMA DICA DE QUANTO ARRISCAR APROXIMADAMENTE! \n\n");
printf(" PARA COMECAR O JOGO PRESSIONE 1. PARA SAIR PRESSIONE 0 : \n\n");
scanf("%d",&a);

if (a == 1)
{
printf(" VAMOS COMECAR! \n\n");

}
else if (a != 0 && a != 1 ){

while(a != 0 || a != 1){

printf("ERROR: ESCOLHA SO ENTRE 0 OU 1 \n\n\n");
}

}
else if (a == 0){

printf("Saindo.. \n");

}

scanf ("%d", &escolha);

a = 1 + (rand() % 1000);


while ( a != b){

if (a > b ) {

printf("%d TENTATIVA..\nDica - O Numero Sorteado, E Menor QE %d : ", contador,a);
contador++;

} else if (a < b){

printf("%d TENTATIVA..\nDica - O Numero Sorteado, E Maior QE %d : ", contador,a);
contador++; }




scanf("%d", &a);
printf("\n\n");

}

num_tenta = contador - 1;
if (a == b){

printf("PARABENS ACERTOU EM %d TENTATIVAS !! \n\n", num_tenta);
printf("FIM DO JOGO.. \n\n");

}
scanf ("%d", &escolha); printf("\n");
teste= escolha;

if (teste == 1) {

printf("\n\nDIGITE UM NUMERO : ");

scanf("%d", &numero);
printf("\n\n");

}
return 0;
}
