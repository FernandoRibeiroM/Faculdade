#include <stdio.h>
int main() {

int num, i, impar;

  printf("\nDigite um numero impar: ");
  scanf("%d", &num);

for (i = num; i >= 0; i--) {
    if (i % 2 != 0) {
    printf ("%d\n", i);
    }
}


  return 0;
}

