#include <stdio.h>
#include <stdlib.h>

int main() {

int i, x, y;  
int div = 0;

    printf("Digite o primeiro valor inteiro e positivo: ");

    scanf("%d", &x);

    printf("Digite o segundo valor inteiro e positivo: ");

    scanf("%d", &y);

 if(x > 0 && x < y ) {

 for (int i = x; i < y; i++){
  printf("%d\n",&i);
}
 for (int j = 2; j <= i; j++){
  printf("%d\n",&i);
}
}      
return 0;
}
