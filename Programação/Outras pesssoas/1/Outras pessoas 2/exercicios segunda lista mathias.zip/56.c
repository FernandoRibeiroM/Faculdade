#include <stdio.h>

int main()
{
    int numero = 2;
    int num_divisores = 0;
    int divisor;

    while(numero < 1000000)
    {
        for(divisor=1; divisor<=1000000; divisor++)
        {
            if(numero%divisor == 0)
            {
                num_divisores++;
            }
        }

        if(num_divisores<=2)
        {
            printf("%i\n",numero);
        }

        num_divisores = 0;
        numero++;
    }
    return 0;
}
