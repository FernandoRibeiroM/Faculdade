#include <stdio.h>

int main() {
  int nlin; //numero de linhas no triangulo
  int m,k,i,j;// contadores e auxiliares

  printf("Entre com o numero inteiro positivo: ");
  scanf("%d",&nlin);
  while (nlin<=0) {
    printf("Numero negativo ou zero.\n",nlin);
    printf("Tente de novo: ");
    scanf("%d",&nlin);
  }

  m=nlin*(nlin+1)/2; //calc numero de elementos na matriz

  for (k=0; m; k++) m /= 10; // pega numero de digitos em m

  m=1;
  for (i=1; i<=nlin; i++) {
    for (j=0; j<i; j++) printf("%*d ",k,j+m);
    printf("\n");
    m +=i;
  }
  return 0;
}
