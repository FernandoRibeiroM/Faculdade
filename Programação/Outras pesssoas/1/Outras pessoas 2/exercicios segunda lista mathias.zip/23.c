#include <stdio.h>


int n,aux,count;

int main()

{

printf("Digite um numero positivo:\n");

scanf("%d",&n);

count = 2;

while (count<n){
aux=n%count;

if (aux==0){

printf("%d e um divisor de %d\n", count,n);
}

count++;

}

return 0;

}
