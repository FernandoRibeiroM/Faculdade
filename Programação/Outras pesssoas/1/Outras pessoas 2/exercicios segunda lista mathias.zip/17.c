#include <stdio.h>

int main(void)
{
int num, soma, i;
printf("Digite um numero positivo:");
scanf("%d", &num);
soma = 0;
i = 0;

while (i < num)
{
  i = i + 1;
  soma = soma + i;
}
printf("A Soma dos numeros naturais e %d\n", soma);
return 0;
}
