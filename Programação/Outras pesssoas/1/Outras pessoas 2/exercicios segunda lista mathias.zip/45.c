#include <stdio.h>

int main (){
	int opcoes;
	float km, ms;

	printf("Digite 1 para (m/s a km/h) 2 para (km/h a m/s) para a conversao: ");
	scanf ("%d", &opcoes);


	if (opcoes <=1){
	printf("Digite um valor em M/S: ");
	scanf ("%f", &ms);
	km = ms*3.6; //Multiplica-se M/s por 3600 segundos

	printf("%2.f M/S e o mesmo que aproximadamente %2.f KM/H", ms, km);
	}

	else {
		printf("Digite um valor em KM/H: ");
	scanf ("%f", &km);
	ms = km/3.6; //dividi k/m por 3600 segundos

	printf("%2.f KM/H e o mesmo que aproximadamente %2.f M/S", km, ms);
	}
	return 0;
	}
