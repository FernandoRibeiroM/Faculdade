#include <stdio.h>

int main(){
	
	int a=0,b=0,c=0;
	
	printf("Digite 3 numeros que some 1000\n");
	printf("Digite o valor A\n");
	scanf("%d", &a);
	printf("Digite o valor B\n");
	scanf("%d", &b);
	printf("Digite o valor C\n");
	scanf("%d", &c);
	
	if(a+b+c==1000){
		printf("Esta correto\n");
	}else{
		printf("O resultado nao deu 1000\n");
	}
	
	
}
