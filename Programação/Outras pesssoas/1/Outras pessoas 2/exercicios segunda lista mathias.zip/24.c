#include<stdio.h>
#include<stdlib.h>

int main()
{
    int valor,i;
    int soma = 0;

    printf("Insira um valor para verificar os seus divisores: \n");
    scanf("%d", &valor);

    for (i = 1; i < valor+1; i++){
    if (valor%i==0){
    printf("E devisor %d \n", i);
    soma = soma + i;
}
}
    printf("A soma dos divisores e: %d \n",soma-valor);
    return 0;
}

