#include <stdio.h>

int main(){

int num, f1, f2, f3, cont,soma;

do {

printf("Digite um numero:\n ");

scanf("%i", &num);

if(num<=0)

printf("Digite um numero positivo!!");

}
while (num<=0);

printf("0 - 1 - \n");

f1=0;f2=1;

num=num-2;

for(cont=0;cont<=num;cont++) {

f3=f2+f1;

printf("%i - ",f3);

f1=f2;f2=f3;

soma = f3 + f1 + f2;

}
printf("\n\nA soma total deles e: %d",soma-1);
return 0;
}
