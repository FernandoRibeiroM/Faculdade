#include <stdio.h>
#include <stdlib.h>
int main()
{
   for (i = 0; i < 10; i++){
        for(j=2; j < vetor[i]; j++){
            if(vetor[i]%j==0){
                printf("Diviudiu");
            }
        }
    {