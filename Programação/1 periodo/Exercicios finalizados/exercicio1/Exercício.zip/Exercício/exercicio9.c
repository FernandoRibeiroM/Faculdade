#include <stdio.h>
#include <math.h>
 int main () {
     float Aa, Bb, Cc;
     printf ("digite o valor de A:");
     scanf  ("%f", &Aa);
     printf ("digite o valor de B:");
     scanf  ("%f", &Bb);
     Cc = Bb;
     Bb = Aa;
     Aa = Cc;
     printf (" A= %f e B= %f", Aa, Bb);

 return 0;
 }
